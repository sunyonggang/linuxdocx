#!/bin/bash
#Program
#	add 1+2+3..+100
#history 2014/4/12
i=0
sum=0
while [ $i != 100 ]
do
	i=$(($i+1))
	sum=$(($sum+$i))
done
echo "i = $i, sum = $sum"
