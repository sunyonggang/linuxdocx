#!/bin/bash
#Program:
#	use it to test exist or not, file or dictory, permission
#History 2014/4/12
echo -e "inout the file you want to check \n"
read -p "filename: " filename
test -z $filename && echo "input a name please" && exit 0
test ! -e $filename && echo "exist not" && exit 0
test -f $filename && echo -e "file \n" || echo -e "directory \n"
test -r $filename && perm="read "
test -w $filename && perm="$perm write "
test -x $filename && perm="$perm execute"
echo "permission= $perm"
