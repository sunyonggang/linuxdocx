#!/bin/bash
#Program:
#        this is my first shell script
#        say hello to you
#History: 2014/4/12
echo "Hello shell"
exit 0       
