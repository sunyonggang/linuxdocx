#!/bin/bash
#Program:
#	this is a show to netstat -tupln check www,ftp,ssh
#History
testing=$(netstat -tupln | grep 80)
if [ "$testing" != "" ];then
	echo "www is on"
fi
testing=$(netstat -tupln | grep 22)
if [ "$testing" != "" ];then
	echo "ssh is on"
fi
testing=$(netstat -tupln | grep 21)
if [ "$testing" != "" ];then
	echo "ftp is on"
fi
