#!/bin/bash
#Program:
#	i want to konw $0,$1,$2
#History
echo "the shell name: " $0
echo "the para number: " $#
echo "the whole para: " $@
echo "the 1st para: " $1
echo "the 2nd para: " $2
