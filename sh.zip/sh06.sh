#!/bin/bash
#Program:
#	there is a choice
#History
read -p "you can choose y/n: " yn
[ $yn == "y" -o $yn == "Y" ] && echo "yes continue" && exit 0
[ $yn == "n" -o $yn == "N" ] && echo "ok, break " && exit 0
echo "i don't know your choice"
