#!/bin/bash
#Program:
#	to show your choice
#History
function printit(){
	echo -n "your choice is "
}
echo "this program will print your selection"
case $1 in
"one")
	printit;echo "$1";;
"two")
	printit;echo "$1";;
*)
	printit;echo "$1";;
esac

