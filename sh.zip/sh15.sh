#!/bin/bash
#Program
#	for do done
#History 2014/4/12
for animal in dogs cats pigs
do
	echo "$animal "
done
