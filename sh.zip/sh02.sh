#!/bin/bash
#Program:
#  	this is a program to show your name
#History: 2014/4/12
read -p "please input your firstname: " firstname
read -p "please input your lastname: " lastname
echo "your name is:  $lastname $firstname "


