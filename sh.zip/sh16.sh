#!/bin/bash
#Program
#	for do done /etc/passwd
#History 2014/2/12
users=$(cut -d ":" -f 1 /etc/passwd)
for user in $users
do 
	echo "$user"
done
