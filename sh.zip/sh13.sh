#!/bin/bash
#Program
#	test while do done
#History 2014/4/12
while [ "$yn" != "y" ] && [ "$yn" != "Y" ]
do
	read -p "input y/Y(es) to stop it: " yn
done
echo "OK"
