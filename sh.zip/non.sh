#!/bin/bash
i=0
while [ $i != "-1" ]
do
	i=$(($i+1))
	echo -e "$i \n"
done
