#!/bin/bash
#Program:
#	there is a choice
#History
read -p "you can choose y/n: " yn
if [ $yn == "y" ] || [ $yn == "Y" ];then
	echo "yes"
elif [ $yn == "n" ] || [ $yn == "N" ];then
	echo "no"
else
	echo "i don't know "
fi
