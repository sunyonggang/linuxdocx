#!/bin/bash
#Program:
#	this is a program to calculate them
#history 2014/4/12
read -p "inout the first: " first
read -p "input the second: " second
total=$(($first * $second))
echo "total is:  $total"

